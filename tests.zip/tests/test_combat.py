import random
import pytest
from src.rpg.combat import calculate_normal_attack, calculate_ability_attack, calculate_enemy_attack, attempt_flee
from src.rpg.characters import Jugador, Enemigo

@pytest.fixture
def player():
    return Jugador("P", "Guerrero", 120, 18, 8, 20, {"nombre":"Golpe","costo":5,"mult":1.8})

@pytest.fixture
def enemy():
    return Enemigo("Goblin", 40, 12, 4, 35)

def test_normal_attack_deterministic(player, enemy):
    random.seed(42)
    dmg = calculate_normal_attack(player, enemy)
    assert dmg >= 1

def test_ability_attack(player, enemy):
    random.seed(42)
    dmg = calculate_ability_attack(player, enemy)
    assert dmg >= 1

def test_enemy_attack(player, enemy):
    random.seed(42)
    dmg = calculate_enemy_attack(enemy, player)
    assert dmg >= 1

def test_flee_probability():
    random.seed(0)
    results = [attempt_flee() for _ in range(100)]
    assert 50 < sum(results) < 70  # roughly 60%