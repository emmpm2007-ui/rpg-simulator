import pytest
from src.rpg.characters import Jugador, Enemigo

def test_jugador_init_defaults():
    j = Jugador("A", "Guerrero", 120, 18, 8, 20, {"nombre": "Golpe", "costo": 5, "mult": 1.8})
    assert j.nombre == "A"
    assert j.nivel == 1
    assert j.xp == 0
    assert j.pociones == 3
    assert j.x == 2 and j.y == 2

def test_jugador_to_dict_and_back():
    j = Jugador("Test", "Mago", 80, 10, 4, 60, {"nombre": "Bola", "costo": 12, "mult": 2.5})
    j.vida = 70
    j.xp = 30
    d = j.to_dict()
    j2 = Jugador.from_dict(d)
    assert j2.nombre == "Test"
    assert j2.vida == 70
    assert j2.xp == 30

def test_enemigo_is_alive():
    e = Enemigo("Goblin", 40, 12, 4, 35)
    assert e.is_alive
    e.vida = 0
    assert not e.is_alive