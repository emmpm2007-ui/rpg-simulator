from src.rpg.progression import subir_nivel
from src.rpg.characters import Jugador

def test_level_up():
    j = Jugador("P", "Guerrero", 120, 18, 8, 20, {"nombre":"G","costo":5,"mult":1.8})
    j.xp = 60  # starting threshold 50, so enough
    old_hp = j.vida_max
    assert subir_nivel(j) == True
    assert j.nivel == 2
    assert j.vida_max == old_hp + 20
    assert j.vida == j.vida_max
    assert j.ataque == 23  # 18+5
    assert j.mana_max == 30  # 20+10
    assert j.xp == 10  # 60-50=10

def test_no_level_up_if_xp_insufficient():
    j = Jugador("P", "Guerrero", 120, 18, 8, 20, {"nombre":"G","costo":5,"mult":1.8})
    j.xp = 30
    assert subir_nivel(j) == False
    assert j.nivel == 1