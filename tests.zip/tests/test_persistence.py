import os
import tempfile
from src.rpg.persistence import guardar_partida, cargar_partida
from src.rpg.characters import Jugador

def test_save_and_load():
    j = Jugador("SaveTest", "Arquero", 90, 14, 6, 30, {"nombre":"Disparo","costo":8,"mult":2.0})
    j.vida = 80
    j.xp = 20
    with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.json') as tmp:
        fname = tmp.name
    try:
        guardar_partida(j, fname)
        loaded = cargar_partida(fname)
        assert loaded is not None
        assert loaded.nombre == "SaveTest"
        assert loaded.vida == 80
        assert loaded.xp == 20
    finally:
        os.unlink(fname)