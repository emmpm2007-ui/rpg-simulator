from src.rpg.map_generator import generar_mapa, generar_enemigo
from src.rpg.constants import MAP_SIZE, MAP_ENEMY_COUNT

def test_generar_mapa_dimensions():
    mapa = generar_mapa()
    assert len(mapa) == MAP_SIZE
    assert all(len(row) == MAP_SIZE for row in mapa)

def test_generar_mapa_spawn_is_empty():
    mapa = generar_mapa()
    # Spawn at (2,2) should be '.' (enemy placement avoids it)
    assert mapa[2][2] == "."

def test_generar_enemigo_scaling():
    e = generar_enemigo(3)
    assert e.vida >= 40  # base goblin 40 * escala
    assert e.xp_reward >= 35