"""
map_generator.py — Procedural map and enemy generation.
"""

import random
from typing import List

from .characters import Enemigo
from .constants import (
    ENEMY_SCALE_PER_LEVEL,
    ENEMY_TYPES,
    ENEMY_XP_PER_LEVEL,
    MAP_ENEMY_COUNT,
    MAP_SIZE,
    PLAYER_SPAWN_X,
    PLAYER_SPAWN_Y,
)


def generar_mapa() -> List[List[str]]:
    """Generate a fresh MAP_SIZE × MAP_SIZE tile grid."""
    mapa: List[List[str]] = [
        ["." for _ in range(MAP_SIZE)] for _ in range(MAP_SIZE)
    ]
    spawn = (PLAYER_SPAWN_X, PLAYER_SPAWN_Y)
    for _ in range(MAP_ENEMY_COUNT):
        x = random.randint(0, MAP_SIZE - 1)
        y = random.randint(0, MAP_SIZE - 1)
        if (x, y) != spawn:
            mapa[y][x] = "E"
    return mapa


def generar_enemigo(nivel: int = 1) -> Enemigo:
    """Generate a level-scaled enemy for a combat encounter."""
    nombre, vida_b, atk_b, def_b, xp_b = random.choice(ENEMY_TYPES)
    escala    = 1 + (nivel - 1) * ENEMY_SCALE_PER_LEVEL
    vida      = int(vida_b * escala)
    ataque    = int(atk_b  * escala)
    defensa   = int(def_b  * escala)
    xp_reward = int(xp_b  * (1 + (nivel - 1) * ENEMY_XP_PER_LEVEL))
    return Enemigo(nombre, vida, ataque, defensa, xp_reward)