"""
renderer.py — Canvas‑based drawing for Tkinter RPG Simulator.

Functions are stateless and take a tkinter.Canvas as the first argument.
No Pygame dependency.
"""

import tkinter as tk


def draw_player(
    canvas: tk.Canvas,
    x: int,
    y: int,
    clase: str,
    size: int = 40,
) -> None:
    """Draw player sprite on a Canvas using geometric shapes."""
    cx, cy = x + size // 2, y + size // 2
    color = {
        "Guerrero": "#9696FF",
        "Mago":     "#6464FF",
        "Arquero":  "#32C832",
    }.get(clase, "#FFFFFF")

    # Cabeza
    canvas.create_oval(cx - 8, y + 4, cx + 8, y + 20, fill=color, outline="")
    # Torso
    canvas.create_rectangle(cx - 5, y + 20, cx + 5, y + 32, fill=color, outline="")
    # Piernas
    canvas.create_line(cx - 5, y + 32, cx - 7, y + 40, width=3, fill=color)
    canvas.create_line(cx + 5, y + 32, cx + 7, y + 40, width=3, fill=color)

    # Accesorio según clase
    if clase == "Guerrero":
        canvas.create_rectangle(cx + 5, y + 16, cx + 10, y + 28, fill="#C0C0C0", outline="")
    elif clase == "Mago":
        canvas.create_oval(cx + 8, y + 18, cx + 14, y + 24, fill="yellow", outline="")
    else:  # Arquero
        canvas.create_line(cx + 6, y + 22, cx + 16, y + 14, width=2, fill="#8B4513")


def draw_enemy(
    canvas: tk.Canvas,
    x: int,
    y: int,
    nombre: str,
    size: int = 40,
) -> None:
    """Draw an enemy based on its archetype."""
    cx, cy = x + size // 2, y + size // 2

    if nombre == "Goblin":
        color = "#32C832"
        canvas.create_oval(cx - 8, y + 4, cx + 8, y + 20, fill=color, outline="")
        canvas.create_rectangle(cx - 5, y + 20, cx + 5, y + 32, fill=color, outline="")
        # Orejas puntiagudas
        canvas.create_polygon(cx - 10, y + 8, cx - 4, y, cx, y + 8, fill=color, outline="")
        canvas.create_polygon(cx + 10, y + 8, cx + 4, y, cx, y + 8, fill=color, outline="")
    elif nombre == "Orco":
        color = "#964B00"
        canvas.create_oval(cx - 9, y + 4, cx + 9, y + 22, fill=color, outline="")
        canvas.create_rectangle(cx - 6, y + 22, cx + 6, y + 34, fill=color, outline="")
        # Colmillos
        canvas.create_polygon(cx - 4, y + 26, cx - 2, y + 32, cx, y + 26, fill="white", outline="")
        canvas.create_polygon(cx + 4, y + 26, cx + 2, y + 32, cx, y + 26, fill="white", outline="")
    else:  # Espectro
        color = "#C8C8FF"
        canvas.create_oval(cx - 6, y + 2, cx + 6, y + 14, fill=color, outline="")
        canvas.create_arc(cx - 10, y + 10, cx + 10, y + 36, start=0, extent=180, fill=color, outline="")
        # Ojos negros
        canvas.create_oval(cx - 3, y + 6, cx - 1, y + 9, fill="black")
        canvas.create_oval(cx + 1, y + 6, cx + 3, y + 9, fill="black")


def draw_bar(
    canvas: tk.Canvas,
    x: int,
    y: int,
    w: int,
    h: int,
    current: int,
    maximum: int,
    color: str,
) -> None:
    """Proportional progress bar (HP, mana, etc.)."""
    if maximum <= 0:
        fill = 0
    else:
        fill = int((current / maximum) * w)

    canvas.create_rectangle(x, y, x + w, y + h, fill="gray", outline="white")
    if fill > 0:
        canvas.create_rectangle(x, y, x + fill, y + h, fill=color, outline="")
    canvas.create_rectangle(x, y, x + w, y + h, outline="white")