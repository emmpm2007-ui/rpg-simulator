"""
combat.py — Damage formulas and combat-resolution utilities.

All functions are **pure** (no side effects, no state mutation).
"""

import random

from .characters import Enemigo, Jugador
from .constants import FLEE_SUCCESS_CHANCE


def calculate_normal_attack(player: Jugador, enemy: Enemigo) -> int:
    """Damage for a standard melee/ranged player attack."""
    raw = int(player.ataque * random.uniform(0.8, 1.2))
    return max(1, raw - enemy.defensa // 2)


def calculate_ability_attack(player: Jugador, enemy: Enemigo) -> int:
    """Damage for the player's class ability."""
    mult = player.habilidad["mult"]
    raw  = int(player.ataque * mult * random.uniform(0.9, 1.1))
    return max(1, raw - enemy.defensa // 3)


def calculate_enemy_attack(enemy: Enemigo, player: Jugador) -> int:
    """Damage dealt by an enemy to the player."""
    raw = int(enemy.ataque * random.uniform(0.8, 1.2))
    return max(1, raw - player.defensa // 2)


def attempt_flee() -> bool:
    """Determine whether a flee attempt succeeds."""
    return random.random() < FLEE_SUCCESS_CHANCE