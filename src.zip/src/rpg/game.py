"""
game.py — Finite State Machine game controller using Tkinter.

This module replaces the Pygame‑based Game class with a Tkinter application.
Each FSM state is a separate Frame; the Game instance switches between them.
All business logic (characters, combat, progression, persistence) remains
in the other modules and is called from the appropriate Frame.
"""

from __future__ import annotations

import tkinter as tk
from typing import Optional

# Core modules (unchanged)
from .characters import Jugador, Enemigo
from .combat import (
    attempt_flee,
    calculate_ability_attack,
    calculate_enemy_attack,
    calculate_normal_attack,
)
from .constants import (
    CLASS_STATS,
    HEAL_POTION_FACTOR,
    POST_COMBAT_REGEN,
    MAP_SIZE,
    PLAYER_SPAWN_X,
    PLAYER_SPAWN_Y,
    MAP_ENEMY_COUNT,
    SAVE_FILE,
)
from .map_generator import generar_mapa, generar_enemigo
from .persistence import guardar_partida, cargar_partida
from .progression import subir_nivel

# ── Helper: sprite drawing on a Canvas ──────────────────────────────────

def draw_player(canvas: tk.Canvas, x: int, y: int, clase: str, size: int = 40) -> None:
    """Draw the player using basic geometric shapes on a tkinter Canvas."""
    cx, cy = x + size//2, y + size//2
    color = {
        "Guerrero": "#9696FF",
        "Mago":     "#6464FF",
        "Arquero":  "#32C832",
    }.get(clase, "#FFFFFF")

    # Cabeza
    canvas.create_oval(cx-8, y+4, cx+8, y+20, fill=color, outline="")
    # Torso
    canvas.create_rectangle(cx-5, y+20, cx+5, y+32, fill=color, outline="")
    # Piernas
    canvas.create_line(cx-5, y+32, cx-7, y+40, width=3, fill=color)
    canvas.create_line(cx+5, y+32, cx+7, y+40, width=3, fill=color)
    # Accesorio de clase
    if clase == "Guerrero":
        canvas.create_rectangle(cx+5, y+16, cx+10, y+28, fill="#C0C0C0", outline="")
    elif clase == "Mago":
        canvas.create_oval(cx+8, y+18, cx+14, y+24, fill="yellow", outline="")
    else:  # Arquero
        canvas.create_line(cx+6, y+22, cx+16, y+14, width=2, fill="#8B4513")


def draw_enemy(canvas: tk.Canvas, x: int, y: int, nombre: str, size: int = 40) -> None:
    """Draw an enemy on a tkinter Canvas."""
    cx, cy = x + size//2, y + size//2
    if nombre == "Goblin":
        color = "#32C832"
        canvas.create_oval(cx-8, y+4, cx+8, y+20, fill=color, outline="")
        canvas.create_rectangle(cx-5, y+20, cx+5, y+32, fill=color, outline="")
        # Orejas
        canvas.create_polygon(cx-10, y+8, cx-4, y, cx, y+8, fill=color, outline="")
        canvas.create_polygon(cx+10, y+8, cx+4, y, cx, y+8, fill=color, outline="")
    elif nombre == "Orco":
        color = "#964B00"
        canvas.create_oval(cx-9, y+4, cx+9, y+22, fill=color, outline="")
        canvas.create_rectangle(cx-6, y+22, cx+6, y+34, fill=color, outline="")
        # Colmillos
        canvas.create_polygon(cx-4, y+26, cx-2, y+32, cx, y+26, fill="white", outline="")
        canvas.create_polygon(cx+4, y+26, cx+2, y+32, cx, y+26, fill="white", outline="")
    else:  # Espectro
        color = "#C8C8FF"
        canvas.create_oval(cx-6, y+2, cx+6, y+14, fill=color, outline="")
        canvas.create_arc(cx-10, y+10, cx+10, y+36, start=0, extent=180, fill=color, outline="")
        canvas.create_oval(cx-3, y+6, cx-1, y+9, fill="black")
        canvas.create_oval(cx+1, y+6, cx+3, y+9, fill="black")


def draw_bar(canvas: tk.Canvas, x: int, y: int, w: int, h: int, current: int, maximum: int, color: str) -> None:
    """Draw a proportional progress bar on a Canvas."""
    if maximum <= 0:
        fill = 0
    else:
        fill = int((current / maximum) * w)
    canvas.create_rectangle(x, y, x+w, y+h, fill="gray", outline="white")
    if fill > 0:
        canvas.create_rectangle(x, y, x+fill, y+h, fill=color, outline="")
    canvas.create_rectangle(x, y, x+w, y+h, outline="white")


# ── Frames for each game state ──────────────────────────────────────────

class MenuFrame(tk.Frame):
    """Main menu with three options."""
    def __init__(self, parent: tk.Widget, game: Game) -> None:
        super().__init__(parent, bg="black")
        self.game = game
        self.selection = 0
        self.options = ["Nueva partida", "Cargar partida", "Salir"]

        tk.Label(self, text="RPG - Pygame Edition", font=("Helvetica", 24, "bold"),
                 fg="white", bg="black").pack(pady=40)
        self.labels = []
        for i, opt in enumerate(self.options):
            lbl = tk.Label(self, text=opt, font=("Helvetica", 18), fg="white", bg="black")
            lbl.pack(pady=10)
            self.labels.append(lbl)
        self._update_highlight()

        tk.Label(self, text="Usa ↑ ↓ y Enter", font=("Helvetica", 14),
                 fg="gray", bg="black").pack(pady=30)

        self.bind_all("<Up>", self._on_up)
        self.bind_all("<Down>", self._on_down)
        self.bind_all("<Return>", self._on_enter)

    def _update_highlight(self) -> None:
        for i, lbl in enumerate(self.labels):
            lbl.config(fg="yellow" if i == self.selection else "white")

    def _on_up(self, event: tk.Event) -> None:
        self.selection = (self.selection - 1) % len(self.options)
        self._update_highlight()

    def _on_down(self, event: tk.Event) -> None:
        self.selection = (self.selection + 1) % len(self.options)
        self._update_highlight()

    def _on_enter(self, event: tk.Event) -> None:
        if self.selection == 0:          # Nueva partida
            self.game.switch_frame(CreationFrame)
        elif self.selection == 1:        # Cargar partida
            loaded = cargar_partida()
            if loaded:
                self.game.player = loaded
                self.game.mapa = generar_mapa()
                self.game.current_msg = "Partida cargada."
                self.game.switch_frame(ExplorationFrame)
            else:
                self.game.current_msg = "No hay partida guardada."
        else:                            # Salir
            self.game.destroy()

    def on_show(self) -> None:
        """Called when this frame is raised; rebind keys."""
        self.focus_set()
        self.bind_all("<Up>", self._on_up)
        self.bind_all("<Down>", self._on_down)
        self.bind_all("<Return>", self._on_enter)

    def on_hide(self) -> None:
        """Unbind keys to avoid interference."""
        self.unbind_all("<Up>")
        self.unbind_all("<Down>")
        self.unbind_all("<Return>")


class CreationFrame(tk.Frame):
    """Two‑step character creation: name then class."""
    def __init__(self, parent: tk.Widget, game: Game) -> None:
        super().__init__(parent, bg="black")
        self.game = game
        self.step = 0           # 0 -> name, 1 -> class
        self.name = ""
        self.class_idx = 0
        self.classes = ["Guerrero", "Mago", "Arquero"]

        self.prompt_label = tk.Label(self, text="Nombre del héroe:", font=("Helvetica", 22, "bold"),
                                     fg="white", bg="black")
        self.prompt_label.pack(pady=30)
        self.name_label = tk.Label(self, text="_", font=("Courier", 20), fg="yellow", bg="black")
        self.name_label.pack(pady=10)
        self.info_label = tk.Label(self, text="Escribe y presiona Enter", font=("Helvetica", 14),
                                   fg="gray", bg="black")
        self.info_label.pack(pady=20)

        self.class_labels = []
        for i, clase in enumerate(self.classes):
            lbl = tk.Label(self, text=clase, font=("Helvetica", 18), fg="white", bg="black")
            self.class_labels.append(lbl)
        self.desc_label = tk.Label(self, text="", font=("Helvetica", 14), fg="gray", bg="black")

        self.bind_all("<Key>", self._on_key)
        self.bind_all("<Return>", self._on_enter)
        self.bind_all("<Left>", self._on_left)
        self.bind_all("<Right>", self._on_right)

    def _on_key(self, event: tk.Event) -> None:
        if self.step == 0:
            if event.keysym == "BackSpace":
                self.name = self.name[:-1]
            elif len(event.char) == 1 and event.char.isprintable() and len(self.name) < 15:
                # Convert to uppercase
                char = event.char.upper() if event.char.isalpha() else event.char
                self.name += char
            self.name_label.config(text=self.name + "_")

    def _on_enter(self, event: tk.Event) -> None:
        if self.step == 0 and self.name.strip():
            self.step = 1
            self._show_class_selection()
        elif self.step == 1:
            self._create_player()

    def _on_left(self, event: tk.Event) -> None:
        if self.step == 1:
            self.class_idx = (self.class_idx - 1) % 3
            self._update_class_highlight()

    def _on_right(self, event: tk.Event) -> None:
        if self.step == 1:
            self.class_idx = (self.class_idx + 1) % 3
            self._update_class_highlight()

    def _show_class_selection(self) -> None:
        self.prompt_label.config(text="Elige tu clase:")
        self.name_label.pack_forget()
        self.info_label.pack_forget()
        for i, lbl in enumerate(self.class_labels):
            lbl.pack(pady=5)
        self._update_class_highlight()
        self.desc_label.pack(pady=10)
        self.info_label.config(text="← → para cambiar, Enter para confirmar")
        self.info_label.pack()

    def _update_class_highlight(self) -> None:
        for i, lbl in enumerate(self.class_labels):
            lbl.config(fg="yellow" if i == self.class_idx else "white")
        clase = self.classes[self.class_idx]
        self.desc_label.config(text=CLASS_STATS[clase]["description"])

    def _create_player(self) -> None:
        nombre = self.name.strip() or "Héroe"
        clase = self.classes[self.class_idx]
        stats = CLASS_STATS[clase]
        self.game.player = Jugador(
            nombre=nombre,
            clase=clase,
            vida=stats["vida"],
            ataque=stats["ataque"],
            defensa=stats["defensa"],
            mana=stats["mana"],
            habilidad=stats["habilidad"],
        )
        self.game.mapa = generar_mapa()
        self.game.current_msg = f"¡Bienvenido, {nombre} el {clase}!"
        self.game.switch_frame(ExplorationFrame)

    def on_show(self) -> None:
        self.focus_set()
        # Rebind keys that might be overridden
        self.bind_all("<Key>", self._on_key)
        self.bind_all("<Return>", self._on_enter)
        self.bind_all("<Left>", self._on_left)
        self.bind_all("<Right>", self._on_right)

    def on_hide(self) -> None:
        self.unbind_all("<Key>")
        self.unbind_all("<Return>")
        self.unbind_all("<Left>")
        self.unbind_all("<Right>")


class ExplorationFrame(tk.Frame):
    """Top‑down map navigation with WASD."""
    def __init__(self, parent: tk.Widget, game: Game) -> None:
        super().__init__(parent, bg="black")
        self.game = game
        self.tile_size = 80
        self.canvas = tk.Canvas(self, width=MAP_SIZE*self.tile_size, height=MAP_SIZE*self.tile_size,
                                bg="black", highlightthickness=0)
        self.canvas.pack(pady=20)
        self.stats_label = tk.Label(self, text="", font=("Helvetica", 16), fg="white", bg="black")
        self.stats_label.pack()
        self.msg_label = tk.Label(self, text="", font=("Helvetica", 14), fg="yellow", bg="black")
        self.msg_label.pack(pady=5)
        self.ctrl_label = tk.Label(self, text="WASD: Mover  |  G: Guardar  |  Q: Salir",
                                   font=("Helvetica", 12), fg="cyan", bg="black")
        self.ctrl_label.pack(pady=10)

        self.bind_all("<KeyPress>", self._on_key)

    def _on_key(self, event: tk.Event) -> None:
        if event.keysym in ("w", "a", "s", "d"):
            jug = self.game.player
            dx, dy = 0, 0
            if event.keysym == "w": dy = -1
            elif event.keysym == "s": dy = 1
            elif event.keysym == "a": dx = -1
            elif event.keysym == "d": dx = 1
            nx, ny = jug.x + dx, jug.y + dy
            if 0 <= nx < MAP_SIZE and 0 <= ny < MAP_SIZE:
                jug.x, jug.y = nx, ny
                if self.game.mapa[ny][nx] == "E":
                    self.game.enemigo_actual = generar_enemigo(jug.nivel)
                    self.game.combat_log = [f"¡Un {self.game.enemigo_actual.nombre} aparece!"]
                    self.game.switch_frame(CombatFrame)
                    return
                self._draw_map()
        elif event.keysym == "g":
            guardar_partida(self.game.player)
            self.msg_label.config(text="Partida guardada.")
        elif event.keysym == "q":
            self.game.destroy()

    def _draw_map(self) -> None:
        self.canvas.delete("all")
        jug = self.game.player
        for row in range(MAP_SIZE):
            for col in range(MAP_SIZE):
                x = col * self.tile_size
                y = row * self.tile_size
                self.canvas.create_rectangle(x, y, x+self.tile_size, y+self.tile_size,
                                             outline="gray")
                if self.game.mapa[row][col] == "E":
                    draw_enemy(self.canvas, x+20, y+20, "Goblin", 40)
                if jug.x == col and jug.y == row:
                    draw_player(self.canvas, x+20, y+20, jug.clase, 40)
        self.stats_label.config(
            text=f"Lvl {jug.nivel}   ❤ {jug.vida}/{jug.vida_max}"
                 f"   Mana {jug.mana}/{jug.mana_max}"
                 f"   XP {jug.xp}/{jug.xp_necesaria}"
                 f"   Pociones {jug.pociones}"
        )

    def on_show(self) -> None:
        self.focus_set()
        self.bind_all("<KeyPress>", self._on_key)
        self._draw_map()
        if self.game.current_msg:
            self.msg_label.config(text=self.game.current_msg)
            self.game.current_msg = ""

    def on_hide(self) -> None:
        self.unbind_all("<KeyPress>")


class CombatFrame(tk.Frame):
    """Turn‑based combat interface."""
    def __init__(self, parent: tk.Widget, game: Game) -> None:
        super().__init__(parent, bg="black")
        self.game = game
        self.create_widgets()
        self.bind_all("<KeyPress>", self._on_key)

    def create_widgets(self) -> None:
        self.player_canvas = tk.Canvas(self, width=200, height=200, bg="#1E1E3C", highlightthickness=2)
        self.player_canvas.grid(row=0, column=0, padx=20, pady=20)
        self.enemy_canvas = tk.Canvas(self, width=200, height=200, bg="#3C1E1E", highlightthickness=2)
        self.enemy_canvas.grid(row=0, column=1, padx=20, pady=20)

        self.player_name = tk.Label(self, text="", font=("Helvetica", 14, "bold"), fg="white", bg="#1E1E3C")
        self.player_name.grid(row=1, column=0)
        self.enemy_name = tk.Label(self, text="", font=("Helvetica", 14, "bold"), fg="white", bg="#3C1E1E")
        self.enemy_name.grid(row=1, column=1)

        self.actions_frame = tk.Frame(self, bg="black")
        self.actions_frame.grid(row=2, column=0, columnspan=2, pady=10)
        actions = ["1. Ataque", "2. Habilidad", "3. Poción", "4. Huir"]
        self.action_labels = []
        for i, txt in enumerate(actions):
            lbl = tk.Label(self.actions_frame, text=txt, font=("Helvetica", 14),
                           fg="yellow", bg="black", padx=10)
            lbl.pack(side=tk.LEFT, padx=20)
            self.action_labels.append(lbl)

        self.log_label = tk.Label(self, text="", font=("Helvetica", 12), fg="white", bg="black",
                                  justify=tk.LEFT, wraplength=400)
        self.log_label.grid(row=3, column=0, columnspan=2, pady=10)

    def _on_key(self, event: tk.Event) -> None:
        if not self.game.enemigo_actual or self.game.enemigo_actual.vida <= 0:
            return
        if self.game.player.vida <= 0:
            return
        key = event.keysym
        if key == "1":
            self._execute("ataque")
        elif key == "2":
            self._execute("habilidad")
        elif key == "3":
            self._execute("pocion")
        elif key == "4":
            self._execute("huir")

    def _execute(self, accion: str) -> None:
        jug = self.game.player
        ene = self.game.enemigo_actual
        log = self.game.combat_log
        log.clear()

        if accion == "ataque":
            dano = calculate_normal_attack(jug, ene)
            ene.vida -= dano
            log.append(f"Atacas: {dano} de daño.")
        elif accion == "habilidad":
            hab = jug.habilidad
            if jug.mana >= hab["costo"]:
                jug.mana -= hab["costo"]
                dano = calculate_ability_attack(jug, ene)
                ene.vida -= dano
                log.append(f"¡{hab['nombre']}! {dano} daño.")
            else:
                log.append("Mana insuficiente.")
                self._update_ui()
                return
        elif accion == "pocion":
            if jug.pociones > 0:
                cura = int(jug.vida_max * HEAL_POTION_FACTOR)
                jug.vida = min(jug.vida_max, jug.vida + cura)
                jug.pociones -= 1
                log.append(f"Usas poción (+{cura} vida).")
            else:
                log.append("Sin pociones.")
                self._update_ui()
                return
        elif accion == "huir":
            if attempt_flee():
                log.append("¡Escapaste!")
                self.game.enemigo_actual = None
                self.game.switch_frame(ExplorationFrame)
                return
            else:
                log.append("¡No puedes escapar!")

        # Enemy counterattack
        if ene.vida > 0:
            dano_e = calculate_enemy_attack(ene, jug)
            jug.vida -= dano_e
            log.append(f"{ene.nombre} te golpea: {dano_e} daño.")

        # Win / loss
        if ene.vida <= 0:
            log.append(f"¡{ene.nombre} derrotado! +{ene.xp_reward} XP")
            jug.xp += ene.xp_reward
            jug.vida = min(jug.vida_max, jug.vida + int(jug.vida_max * POST_COMBAT_REGEN))
            jug.mana = min(jug.mana_max, jug.mana + int(jug.mana_max * POST_COMBAT_REGEN))
            while subir_nivel(jug):
                log.append(f"¡Subiste al nivel {jug.nivel}!")
            self.game.mapa[jug.y][jug.x] = "."
            self.game.enemigo_actual = None
            self.game.switch_frame(ExplorationFrame)
            return
        elif jug.vida <= 0:
            log.append("Has sido derrotado...")
            self.game.switch_frame(GameOverFrame)
            return

        self._update_ui()

    def _update_ui(self) -> None:
        """Redraw all dynamic elements."""
        jug = self.game.player
        ene = self.game.enemigo_actual
        if not ene:
            return

        # Player canvas
        self.player_canvas.delete("all")
        draw_player(self.player_canvas, 80, 40, jug.clase, 80)
        self.player_name.config(text=jug.nombre)
        # Bars
        draw_bar(self.player_canvas, 30, 140, 140, 15, jug.vida, jug.vida_max, "#32C832")
        draw_bar(self.player_canvas, 30, 165, 140, 15, jug.mana, jug.mana_max, "#6464FF")
        self.player_canvas.create_text(100, 185, text=f"Pociones: {jug.pociones}",
                                       fill="white", font=("Helvetica", 10))

        # Enemy canvas
        self.enemy_canvas.delete("all")
        draw_enemy(self.enemy_canvas, 80, 40, ene.nombre, 80)
        self.enemy_name.config(text=ene.nombre)
        draw_bar(self.enemy_canvas, 30, 140, 140, 15, ene.vida, ene.vida_max, "#C83232")
        self.enemy_canvas.create_text(100, 165, text=f"Vida: {ene.vida}/{ene.vida_max}",
                                      fill="white", font=("Helvetica", 10))

        # Log
        self.log_label.config(text="\n".join(self.game.combat_log))

    def on_show(self) -> None:
        self.focus_set()
        self.bind_all("<KeyPress>", self._on_key)
        self._update_ui()

    def on_hide(self) -> None:
        self.unbind_all("<KeyPress>")


class GameOverFrame(tk.Frame):
    """Game over screen."""
    def __init__(self, parent: tk.Widget, game: Game) -> None:
        super().__init__(parent, bg="black")
        self.game = game
        tk.Label(self, text="GAME OVER", font=("Helvetica", 36, "bold"),
                 fg="red", bg="black").pack(pady=50)
        tk.Label(self, text="Presiona Enter para volver al menú", font=("Helvetica", 16),
                 fg="white", bg="black").pack(pady=30)
        self.bind_all("<Return>", self._on_enter)

    def _on_enter(self, event: tk.Event) -> None:
        self.game.player = None
        self.game.switch_frame(MenuFrame)

    def on_show(self) -> None:
        self.focus_set()
        self.bind_all("<Return>", self._on_enter)

    def on_hide(self) -> None:
        self.unbind_all("<Return>")


# ── Main Game class ─────────────────────────────────────────────────────

class Game(tk.Tk):
    """Main application window that manages the FSM via frames."""

    def __init__(self) -> None:
        super().__init__()
        self.title("RPG Simulator")
        self.geometry("800x600")
        self.resizable(False, False)
        self.configure(bg="black")

        # Shared game state (same as original)
        self.player: Optional[Jugador] = None
        self.mapa = []
        self.enemigo_actual: Optional[Enemigo] = None
        self.combat_log: list[str] = []
        self.current_msg: str = ""

        # Frame registry
        self.frames: dict[type, tk.Frame] = {}
        for FrameClass in (MenuFrame, CreationFrame, ExplorationFrame, CombatFrame, GameOverFrame):
            frame = FrameClass(self, self)
            self.frames[FrameClass] = frame
            frame.grid(row=0, column=0, sticky="nsew")

        self.grid_rowconfigure(0, weight=1)
        self.grid_columnconfigure(0, weight=1)

        self.switch_frame(MenuFrame)

    def switch_frame(self, frame_class: type) -> None:
        """Raise a new frame and call its on_show."""
        # Hide current frame
        current = self.frames.get(type(self.frames.get(next(iter(self.frames)))))  # won't work easily
        # Simpler: iterate to find currently visible frame and call on_hide
        for f in self.frames.values():
            if f.winfo_ismapped():
                f.on_hide()
        new_frame = self.frames[frame_class]
        new_frame.tkraise()
        new_frame.on_show()

    def run(self) -> None:
        """Start the Tkinter main loop."""
        self.mainloop()