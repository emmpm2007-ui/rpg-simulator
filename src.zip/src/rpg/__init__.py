"""
rpg — RPG Simulator engine package.

Convenience re-exports.
Usage::

    from src.rpg import Game
    Game().run()

Submodules can be imported directly for testing or extension.
"""

from .game import Game
from .characters import Jugador, Enemigo

__all__ = ["Game", "Jugador", "Enemigo"]
__version__ = "1.0.0"