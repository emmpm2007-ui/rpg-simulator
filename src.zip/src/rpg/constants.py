"""
constants.py — Global configuration for RPG Simulator.

All tunable parameters are defined here as module-level constants.
Changing a value propagates throughout the entire engine.
"""

# ── Screen (used by Tkinter, but kept for reference) ────────────────────
SCREEN_WIDTH: int = 800
SCREEN_HEIGHT: int = 600
TILE_SIZE: int = 80
MAP_SIZE: int = 5
FPS: int = 30  # Not used in Tkinter version

# ── Colors (hex strings for Tkinter) ────────────────────────────────────
BLACK  = "#000000"
WHITE  = "#FFFFFF"
GRAY   = "#808080"
RED    = "#C83232"
GREEN  = "#32C832"
BLUE   = "#3232C8"
YELLOW = "#FFFF00"
PURPLE = "#C800C8"
CYAN   = "#00C8C8"
ORANGE = "#FFA500"
BROWN  = "#8B4513"

# ── Character Class Definitions ─────────────────────────────────────────
CLASS_STATS: dict = {
    "Guerrero": {
        "vida":      120,
        "ataque":    18,
        "defensa":   8,
        "mana":      20,
        "habilidad": {"nombre": "Golpe Fuerte",    "costo": 5,  "mult": 1.8},
        "description": "Vida alta, ataque fuerte",
    },
    "Mago": {
        "vida":      80,
        "ataque":    10,
        "defensa":   4,
        "mana":      60,
        "habilidad": {"nombre": "Bola de Fuego",   "costo": 12, "mult": 2.5},
        "description": "Mucho maná, hechizo devastador",
    },
    "Arquero": {
        "vida":      90,
        "ataque":    14,
        "defensa":   6,
        "mana":      30,
        "habilidad": {"nombre": "Disparo Certero", "costo": 8,  "mult": 2.0},
        "description": "Equilibrado, disparo preciso",
    },
}

# ── Enemy Archetypes: (nombre, base_hp, base_atk, base_def, base_xp) ─────
ENEMY_TYPES: list = [
    ("Goblin",   40, 12, 4, 35),
    ("Orco",     65, 18, 6, 50),
    ("Espectro", 50, 14, 3, 45),
]

# ── Progression ─────────────────────────────────────────────────────────
LEVEL_UP_HP_GAIN        = 20
LEVEL_UP_ATK_GAIN       = 5
LEVEL_UP_DEF_GAIN       = 2
LEVEL_UP_MANA_GAIN      = 10
LEVEL_UP_XP_MULTIPLIER  = 1.25
STARTING_XP_THRESHOLD   = 50

# ── Combat ──────────────────────────────────────────────────────────────
FLEE_SUCCESS_CHANCE = 0.60
HEAL_POTION_FACTOR  = 0.40   # fraction of vida_max restored per potion
POST_COMBAT_REGEN   = 0.20   # fraction of max HP/mana recovered after a kill
STARTING_POTIONS    = 3

# ── Enemy Scaling ───────────────────────────────────────────────────────
ENEMY_SCALE_PER_LEVEL = 0.15  # +15% stats per level above 1
ENEMY_XP_PER_LEVEL    = 0.20  # +20% XP reward per level above 1

# ── Map ─────────────────────────────────────────────────────────────────
MAP_ENEMY_COUNT = 7
PLAYER_SPAWN_X  = 2
PLAYER_SPAWN_Y  = 2

# ── Misc ────────────────────────────────────────────────────────────────
MOVE_DEBOUNCE_MS     = 150   # (not used in Tkinter, movement is discrete)
TEMP_MSG_DURATION_MS = 2000  # (not used in Tkinter)
SAVE_FILE            = "savegame.json"