"""
progression.py — Character level-up and XP system.
"""

from .characters import Jugador
from .constants import (
    LEVEL_UP_ATK_GAIN,
    LEVEL_UP_DEF_GAIN,
    LEVEL_UP_HP_GAIN,
    LEVEL_UP_MANA_GAIN,
    LEVEL_UP_XP_MULTIPLIER,
)


def subir_nivel(jugador: Jugador) -> bool:
    """Apply a single level-up to jugador if the XP threshold is met.

    Returns True if a level-up occurred, False otherwise.
    """
    if jugador.xp < jugador.xp_necesaria:
        return False

    excedente          = jugador.xp - jugador.xp_necesaria
    jugador.nivel     += 1
    jugador.xp         = excedente
    jugador.xp_necesaria = int(jugador.xp_necesaria * LEVEL_UP_XP_MULTIPLIER)
    jugador.vida_max  += LEVEL_UP_HP_GAIN
    jugador.vida       = jugador.vida_max
    jugador.ataque    += LEVEL_UP_ATK_GAIN
    jugador.defensa   += LEVEL_UP_DEF_GAIN
    jugador.mana_max  += LEVEL_UP_MANA_GAIN
    jugador.mana       = jugador.mana_max
    return True