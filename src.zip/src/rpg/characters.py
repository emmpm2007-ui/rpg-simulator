"""
characters.py — Player and Enemy entity data models.

``Jugador``
    Player character. Holds all stats, inventory, map position, and
    progression state. Supports JSON serialization for save-game persistence.

``Enemigo``
    Enemy entity scoped to a single combat encounter. Stateless beyond
    combat attributes; not serialized.
"""

from __future__ import annotations

from typing import Any

from .constants import (
    PLAYER_SPAWN_X,
    PLAYER_SPAWN_Y,
    STARTING_POTIONS,
    STARTING_XP_THRESHOLD,
)


class Jugador:
    """Player character entity.

    Attributes:
        nombre:       Display name (max 15 characters in creation UI).
        clase:        One of ``'Guerrero'``, ``'Mago'``, ``'Arquero'``.
        vida_max:     Maximum HP; grows on level-up.
        vida:         Current HP.
        ataque:       Base attack stat used in damage formulas.
        defensa:      Base defence stat used for damage mitigation.
        mana_max:     Maximum mana pool.
        mana:         Current mana; consumed by class abilities.
        nivel:        Current level (starts at 1).
        xp:           Accumulated experience points.
        xp_necesaria: XP required to trigger the next level-up.
        habilidad:    Dict ``{nombre: str, costo: int, mult: float}``.
        pociones:     Healing potions remaining (starts at 3).
        x, y:         Current tile coordinates on the map grid.
    """

    def __init__(
        self,
        nombre: str,
        clase: str,
        vida: int,
        ataque: int,
        defensa: int,
        mana: int,
        habilidad: dict[str, Any],
    ) -> None:
        self.nombre    = nombre
        self.clase     = clase
        self.vida_max  = vida
        self.vida      = vida
        self.ataque    = ataque
        self.defensa   = defensa
        self.mana_max  = mana
        self.mana      = mana
        self.nivel     = 1
        self.xp        = 0
        self.xp_necesaria = STARTING_XP_THRESHOLD
        self.habilidad = habilidad
        self.pociones  = STARTING_POTIONS
        self.x         = PLAYER_SPAWN_X
        self.y         = PLAYER_SPAWN_Y

    # ── Serialization ─────────────────────────────────────────────────

    def to_dict(self) -> dict[str, Any]:
        """Serialize the full player state to a plain dictionary."""
        return {
            "nombre":       self.nombre,
            "clase":        self.clase,
            "vida_max":     self.vida_max,
            "vida":         self.vida,
            "ataque":       self.ataque,
            "defensa":      self.defensa,
            "mana_max":     self.mana_max,
            "mana":         self.mana,
            "nivel":        self.nivel,
            "xp":           self.xp,
            "xp_necesaria": self.xp_necesaria,
            "habilidad":    self.habilidad,
            "pociones":     self.pociones,
            "x":            self.x,
            "y":            self.y,
        }

    @staticmethod
    def from_dict(data: dict[str, Any]) -> "Jugador":
        """Reconstruct a Jugador from a save-game dictionary."""
        j = Jugador(
            nombre    = data["nombre"],
            clase     = data["clase"],
            vida      = data["vida_max"],
            ataque    = data["ataque"],
            defensa   = data["defensa"],
            mana      = data["mana_max"],
            habilidad = data["habilidad"],
        )
        j.vida         = data.get("vida",         data["vida_max"])
        j.mana         = data.get("mana",         data["mana_max"])
        j.nivel        = data.get("nivel",        1)
        j.xp           = data.get("xp",           0)
        j.xp_necesaria = data.get("xp_necesaria", STARTING_XP_THRESHOLD)
        j.pociones     = data.get("pociones",     STARTING_POTIONS)
        j.x            = data.get("x",            PLAYER_SPAWN_X)
        j.y            = data.get("y",            PLAYER_SPAWN_Y)
        return j

    def __repr__(self) -> str:
        return (
            f"Jugador({self.nombre!r}, {self.clase!r}, "
            f"vida={self.vida}/{self.vida_max}, nivel={self.nivel})"
        )


class Enemigo:
    """Enemy entity for a single combat encounter.

    Enemies are generated procedurally each time the player steps onto an
    enemy tile and are **not** serialized to disk.

    Attributes:
        nombre:    Archetype — ``'Goblin'``, ``'Orco'``, or ``'Espectro'``.
        vida_max:  Maximum HP.
        vida:      Current HP.
        ataque:    Base attack stat.
        defensa:   Defence stat.
        xp_reward: XP awarded on defeat.
    """

    def __init__(
        self,
        nombre: str,
        vida: int,
        ataque: int,
        defensa: int,
        xp_reward: int,
    ) -> None:
        self.nombre    = nombre
        self.vida_max  = vida
        self.vida      = vida
        self.ataque    = ataque
        self.defensa   = defensa
        self.xp_reward = xp_reward

    @property
    def is_alive(self) -> bool:
        """Return True if the enemy still has HP remaining."""
        return self.vida > 0

    def __repr__(self) -> str:
        return (
            f"Enemigo({self.nombre!r}, "
            f"vida={self.vida}/{self.vida_max}, ataque={self.ataque})"
        )