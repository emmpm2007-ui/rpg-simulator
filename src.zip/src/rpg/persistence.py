"""
persistence.py — Save/load game state via JSON serialization.
"""

import json
import logging
import os
from typing import Optional

from .characters import Jugador
from .constants import SAVE_FILE

logger = logging.getLogger(__name__)


def guardar_partida(jugador: Jugador, archivo: str = SAVE_FILE) -> None:
    """Serialize jugador and write it to archivo as indented JSON."""
    with open(archivo, "w", encoding="utf-8") as f:
        json.dump(jugador.to_dict(), f, indent=4, ensure_ascii=False)
    logger.info("Game saved → %s", archivo)


def cargar_partida(archivo: str = SAVE_FILE) -> Optional[Jugador]:
    """Deserialize a player from a JSON save file.

    Returns None on failure.
    """
    if not os.path.exists(archivo):
        logger.debug("Save file not found: %s", archivo)
        return None
    try:
        with open(archivo, "r", encoding="utf-8") as f:
            data = json.load(f)
        logger.info("Game loaded ← %s", archivo)
        return Jugador.from_dict(data)
    except (json.JSONDecodeError, KeyError, TypeError) as exc:
        logger.warning("Could not load save %s: %s", archivo, exc)
        return None